// Optional macOS enrichment. Uses only Apple frameworks; no package dependencies.
import Foundation
import AppKit
import CoreGraphics

func modeJSON(_ mode: CGDisplayMode) -> [String: Any] {
    return ["width": mode.width, "height": mode.height,
            "pixel_width": mode.pixelWidth, "pixel_height": mode.pixelHeight,
            "refresh_hz": mode.refreshRate > 0 ? mode.refreshRate as Any : NSNull(),
            "io_flags": mode.ioFlags, "mode_id": mode.ioDisplayModeID,
            "source": "CoreGraphics; OS-exposed mode, not a verified physical panel timing"]
}
var count: UInt32 = 0
let first = CGGetOnlineDisplayList(0, nil, &count)
guard first == .success else { fputs("CGGetOnlineDisplayList failed\n", stderr); exit(1) }
var ids = [CGDirectDisplayID](repeating: 0, count: max(Int(count), 1))
let second = CGGetOnlineDisplayList(UInt32(ids.count), &ids, &count)
guard second == .success else { fputs("CGGetOnlineDisplayList failed\n", stderr); exit(1) }
let rows: [[String: Any]] = ids.prefix(Int(count)).map { id in
    let size = CGDisplayScreenSize(id)
    let bounds = CGDisplayBounds(id)
    let screen = NSScreen.screens.first {
        ($0.deviceDescription[NSDeviceDescriptionKey("NSScreenNumber")] as? NSNumber)?.uint32Value == id
    }
    var row: [String: Any] = [
        "display_id": id, "vendor_id": CGDisplayVendorNumber(id),
        "product_id": CGDisplayModelNumber(id), "serial_numeric": CGDisplaySerialNumber(id),
        "built_in": CGDisplayIsBuiltin(id) != 0, "active": CGDisplayIsActive(id) != 0,
        "main": CGDisplayIsMain(id) != 0, "in_mirror_set": CGDisplayIsInMirrorSet(id) != 0,
        "mirrors_display_id": CGDisplayMirrorsDisplay(id), "rotation_degrees": CGDisplayRotation(id),
        "width_mm": size.width > 0 ? size.width as Any : NSNull(),
        "height_mm": size.height > 0 ? size.height as Any : NSNull(),
        "desktop_bounds": ["x": bounds.origin.x, "y": bounds.origin.y,
                           "width": bounds.width, "height": bounds.height],
        "current_mode": CGDisplayCopyDisplayMode(id).map(modeJSON) as Any? ?? NSNull(),
        "available_modes": (CGDisplayCopyAllDisplayModes(id,
            [kCGDisplayShowDuplicateLowResolutionModes: true] as CFDictionary) as? [CGDisplayMode] ?? []).map(modeJSON)
    ]
    if let uuid = CGDisplayCreateUUIDFromDisplayID(id)?.takeRetainedValue() {
        row["display_uuid"] = CFUUIDCreateString(nil, uuid) as String
    }
    if #available(macOS 10.15, *), let s = screen { row["name"] = s.localizedName }
    if let s = screen {
        row["backing_scale_factor"] = s.backingScaleFactor
        row["color_space"] = s.colorSpace?.localizedName ?? "Unknown"
    }
    return row
}
let data = try JSONSerialization.data(withJSONObject: rows, options: [.prettyPrinted, .sortedKeys])
FileHandle.standardOutput.write(data)
