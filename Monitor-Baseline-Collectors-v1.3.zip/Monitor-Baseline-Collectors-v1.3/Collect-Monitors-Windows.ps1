#requires -Version 5.1
<# Read-only monitor collection. Run in a local Windows desktop session.
   Keep WindowsDisplay.cs beside this script. No administrator rights required.
   JSON is the authoritative report; CSV is a quick index. #>
[CmdletBinding()]
param(
    [string]$OutputDirectory = '',
    [string]$Location = '',
    [string]$ComputerLabel = $env:COMPUTERNAME
)
$ErrorActionPreference = 'Stop'
if ([Environment]::OSVersion.Platform -ne [PlatformID]::Win32NT) { throw 'Run this collector on Windows.' }
# Resolve the Explorer desktop in THIS session, not the account in the elevated
# PowerShell token. Known Folder resolution honors OneDrive/folder redirection.
function Get-InteractiveDesktop {
    if (-not ('MonitorDesktopContextV12' -as [type])) {
        Add-Type -TypeDefinition @'
using System;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Security.Principal;
public sealed class MonitorDesktopContextV12 {
    public string DesktopPath;
    public string UserSid;
    public string AccountName;
    public uint ShellProcessId;
    [DllImport("user32.dll")] static extern IntPtr GetShellWindow();
    [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr window, out uint processId);
    [DllImport("kernel32.dll", SetLastError=true)] static extern IntPtr OpenProcess(uint access, bool inherit, uint pid);
    [DllImport("advapi32.dll", SetLastError=true)] static extern bool OpenProcessToken(IntPtr process, uint access, out IntPtr token);
    [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr handle);
    [DllImport("shell32.dll", CharSet=CharSet.Unicode)] static extern int SHGetKnownFolderPath(ref Guid folder, uint flags, IntPtr token, out IntPtr path);
    public static MonitorDesktopContextV12 Resolve() {
        IntPtr shell=GetShellWindow();
        if(shell==IntPtr.Zero) throw new InvalidOperationException("No Explorer desktop was found in this session. Run from the signed-in user's desktop session.");
        uint pid;
        GetWindowThreadProcessId(shell,out pid);
        IntPtr process=OpenProcess(0x1000,false,pid);
        if(process==IntPtr.Zero) throw new Win32Exception(Marshal.GetLastWin32Error(),"Cannot inspect the desktop shell.");
        IntPtr token=IntPtr.Zero, path=IntPtr.Zero;
        try {
            // TOKEN_QUERY | TOKEN_DUPLICATE | TOKEN_IMPERSONATE, as required
            // for resolving another user's Known Folder. No process is launched.
            if(!OpenProcessToken(process,0x000E,out token)) throw new Win32Exception(Marshal.GetLastWin32Error(),"Cannot read the desktop user's token. Try a normal Terminal under that user.");
            Guid desktop=new Guid("B4BFCC3A-DB2C-424C-B029-7FE99A87C641");
            int hr=SHGetKnownFolderPath(ref desktop,0x4000,token,out path);
            if(hr!=0) Marshal.ThrowExceptionForHR(hr);
            using(WindowsIdentity identity=new WindowsIdentity(token)) {
                string desktopPath=Marshal.PtrToStringUni(path);
                if(String.IsNullOrWhiteSpace(desktopPath) || identity.User==null) throw new InvalidOperationException("Desktop identity/path could not be resolved.");
                return new MonitorDesktopContextV12 {DesktopPath=desktopPath,UserSid=identity.User.Value,AccountName=identity.Name,ShellProcessId=pid};
            }
        } finally {
            if(path!=IntPtr.Zero) Marshal.FreeCoTaskMem(path);
            if(token!=IntPtr.Zero) CloseHandle(token);
            CloseHandle(process);
        }
    }
}
'@
    }
    return [MonitorDesktopContextV12]::Resolve()
}
function Grant-DesktopUserAccess {
    param([string]$Path, [string]$UserSid, [switch]$Directory)
    $sid = New-Object Security.Principal.SecurityIdentifier($UserSid)
    $inheritance = [Security.AccessControl.InheritanceFlags]::None
    if ($Directory) { $inheritance = [Security.AccessControl.InheritanceFlags]'ContainerInherit, ObjectInherit' }
    $rule = New-Object Security.AccessControl.FileSystemAccessRule(
        $sid, [Security.AccessControl.FileSystemRights]::Modify, $inheritance,
        [Security.AccessControl.PropagationFlags]::None, [Security.AccessControl.AccessControlType]::Allow)
    $acl = Get-Acl -LiteralPath $Path
    $acl.AddAccessRule($rule)
    Set-Acl -LiteralPath $Path -AclObject $acl
}
$desktopUser = Get-InteractiveDesktop
if ([string]::IsNullOrWhiteSpace($OutputDirectory)) {
    $OutputDirectory = Join-Path $desktopUser.DesktopPath 'Monitor-Baselines'
}
Write-Host "Desktop user: $($desktopUser.AccountName)"
Write-Host "Output directory: $OutputDirectory"
# Grant only the desktop user access; retain existing ACLs. Do not grant Everyone
# access, take ownership of the Desktop, or change system/network policies.
try {
    New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null
    Grant-DesktopUserAccess -Path $OutputDirectory -UserSid $desktopUser.UserSid -Directory
} catch {
    throw "Cannot prepare output for desktop user $($desktopUser.AccountName) at '$OutputDirectory': $($_.Exception.Message). For a redirected network Desktop, run in that user's normal Terminal or supply a local -OutputDirectory."
}
$stamp = [DateTime]::UtcNow.ToString('yyyyMMddTHHmmssfffZ')
$scanId = [guid]::NewGuid().ToString()
$out = Join-Path $OutputDirectory ('Windows-' + $stamp + '-' + $scanId.Substring(0,8))
$rawDir = Join-Path $out 'raw'
New-Item -ItemType Directory -Path $rawDir -Force | Out-Null
Grant-DesktopUserAccess -Path $out -UserSid $desktopUser.UserSid -Directory
Grant-DesktopUserAccess -Path $rawDir -UserSid $desktopUser.UserSid -Directory
$warnings = New-Object 'System.Collections.Generic.List[string]'
function Warn([string]$text) { $warnings.Add($text); Write-Warning $text }
function Save-Json($value, [string]$path) { ConvertTo-Json -InputObject $value -Depth 30 | Set-Content -LiteralPath $path -Encoding UTF8 }
function Plain($value) {
    if ($null -eq $value) { return $null }
    if ($value.GetType().FullName -eq 'Microsoft.Management.Infrastructure.CimInstance') {
        $obj = [ordered]@{}
        foreach ($p in $value.CimInstanceProperties) { $obj[$p.Name] = Plain $p.Value }
        return [pscustomobject]$obj
    }
    if ($value -is [Array]) { $list = @(); foreach ($v in $value) { $list += ,(Plain $v) }; return ,$list }
    return $value
}
function Text-ID($values) { return (-join @($values | Where-Object { $_ -gt 0 } | ForEach-Object { [char]$_ })).Trim() }
function Instance-Key([string]$s) {
    if (-not $s) { return '' }
    if ($s.StartsWith('\\?\')) {
        $parts = $s.Split('#')
        if ($parts.Length -ge 3) { $s = 'DISPLAY\' + $parts[1] + '\' + $parts[2] }
    } else { $s = $s -replace '_\d+$','' }
    return $s.ToUpperInvariant()
}
function Decode-Edid([byte[]]$b) {
    $checks = @()
    for ($i=0; $i+127 -lt $b.Length; $i+=128) {
        $sum=0; for($j=$i; $j -lt $i+128; $j++) { $sum += $b[$j] }
        $checks += (($sum % 256) -eq 0)
    }
    $sha = [Security.Cryptography.SHA256]::Create()
    try { $hash = ([BitConverter]::ToString($sha.ComputeHash($b))).Replace('-','').ToLowerInvariant() } finally { $sha.Dispose() }
    $r = [ordered]@{ byte_count=$b.Length; sha256=$hash; hex=([BitConverter]::ToString($b)).Replace('-',''); block_checksums_valid=$checks }
    if ($b.Length -lt 128 -or ([BitConverter]::ToString($b[0..7])) -ne '00-FF-FF-FF-FF-FF-FF-00' -or -not $checks[0]) {
        $r.decode_status='Invalid/truncated base EDID; raw bytes retained'; return [pscustomobject]$r
    }
    $vendor = ([int]$b[8] -shl 8) -bor $b[9]
    $r.vendor_id = $vendor
    $r.manufacturer_code = -join @(10,5,0 | ForEach-Object { [char](64 + (($vendor -shr $_) -band 31)) })
    $r.product_id = [int]$b[10] + ([int]$b[11] -shl 8)
    $r.serial_numeric = [BitConverter]::ToUInt32($b,12)
    $r.manufacture_week = if ($b[16] -ge 1 -and $b[16] -le 54) { [int]$b[16] } else { $null }
    $r.year = 1990 + [int]$b[17]
    $r.year_kind = if ($b[16] -eq 255) { 'model_year' } else { 'manufacture_year' }
    $r.edid_version = "$($b[18]).$($b[19])"
    $r.width_cm = if ($b[21] -gt 0 -and $b[22] -gt 0) { [int]$b[21] } else { $null }
    $r.height_cm = if ($b[21] -gt 0 -and $b[22] -gt 0) { [int]$b[22] } else { $null }
    $r.extension_blocks_declared = [int]$b[126]
    $r.extension_blocks_captured = [math]::Max(0,[math]::Floor($b.Length/128)-1)
    $r.base_detailed_timings = @()
    for ($offset=54; $offset -le 108; $offset+=18) {
        $clock = ([int]$b[$offset]+([int]$b[$offset+1] -shl 8))*10000
        if ($clock -eq 0) {
            $kind=$b[$offset+3]
            $txt=([Text.Encoding]::ASCII.GetString($b,$offset+5,13)).Trim([char[]]@(0,10,13,32))
            if ($kind -eq 252) { $r.model_name=$txt }
            if ($kind -eq 255) { $r.serial_text=$txt }
            if ($kind -eq 253) { $r.range_descriptor_hex=([BitConverter]::ToString($b,$offset,18)).Replace('-','') }
        } else {
            $w=[int]$b[$offset+2]+(([int]$b[$offset+4] -band 240) -shl 4)
            $h=[int]$b[$offset+5]+(([int]$b[$offset+7] -band 240) -shl 4)
            $hb=[int]$b[$offset+3]+(([int]$b[$offset+4] -band 15) -shl 8)
            $vb=[int]$b[$offset+6]+(([int]$b[$offset+7] -band 15) -shl 8)
            $interlaced=($b[$offset+17] -band 128) -ne 0
            $r.base_detailed_timings += [pscustomobject]@{
                width=$w; height_as_encoded=$h; interlaced=$interlaced; pixel_clock_hz=$clock
                refresh_hz=if (-not $interlaced -and ($w+$hb)*($h+$vb) -gt 0) { [math]::Round($clock/(($w+$hb)*($h+$vb)),4) } else { $null }
                source='EDID base detailed timing; not independently verified native resolution'
            }
        }
    }
    $r.decode_status='Valid base EDID; extension bytes retained for later decoding'
    return [pscustomobject]$r
}

Write-Host 'Collecting monitor identity, advertised timings, and active display paths...'
$classes = @('WmiMonitorID','WmiMonitorBasicDisplayParams','WmiMonitorConnectionParams',
    'WmiMonitorListedSupportedSourceModes','WmiMonitorListedFrequencyRanges',
    'WmiMonitorColorCharacteristics','WmiMonitorDigitalVideoInputParams','WmiMonitorBrightness')
$raw = @{}
$keys = @{}
foreach ($class in $classes) {
    try {
        $raw[$class] = @(Get-CimInstance -Namespace root/wmi -ClassName $class | ForEach-Object { Plain $_ })
        foreach ($item in $raw[$class]) { $key=Instance-Key $item.InstanceName; if ($key) { $keys[$key]=$true } }
    } catch { $raw[$class]=@(); Warn "$class unavailable: $($_.Exception.Message)" }
}
Save-Json $raw (Join-Path $rawDir 'monitor-wmi.json')
$pnp = @()
try {
    $pnp = @(Get-PnpDevice -Class Monitor -PresentOnly | Select-Object InstanceId,FriendlyName,Status)
    foreach ($p in $pnp) { if ($p.InstanceId) { $keys[(Instance-Key $p.InstanceId)]=$true } }
} catch { Warn "Present monitor PnP inventory unavailable: $($_.Exception.Message)" }
Save-Json $pnp (Join-Path $rawDir 'present-monitor-devices.json')
$native = @()
try {
    if (-not ('MonitorBaselineNative' -as [type])) { Add-Type -Path (Join-Path $PSScriptRoot 'WindowsDisplay.cs') }
    $native = @([MonitorBaselineNative]::Collect())
    foreach ($n in $native) { $key=Instance-Key $n.device_path; if ($key) { $keys[$key]=$true } }
} catch { Warn "Native display queries unavailable: $($_.Exception.Message)" }
Save-Json $native (Join-Path $rawDir 'windows-display-paths.json')
try {
    $gpus = @(Get-CimInstance Win32_VideoController | Select-Object Name, PNPDeviceID, DriverVersion, DriverDate, VideoProcessor)
} catch { $gpus=@(); Warn "GPU context unavailable: $($_.Exception.Message)" }
Save-Json $gpus (Join-Path $rawDir 'graphics-adapters.json')
$monitors = @()
foreach ($key in ($keys.Keys | Sort-Object)) {
    $id = @($raw.WmiMonitorID | Where-Object { (Instance-Key $_.InstanceName) -eq $key }) | Select-Object -First 1
    $basic = @($raw.WmiMonitorBasicDisplayParams | Where-Object { (Instance-Key $_.InstanceName) -eq $key }) | Select-Object -First 1
    $listed = @($raw.WmiMonitorListedSupportedSourceModes | Where-Object { (Instance-Key $_.InstanceName) -eq $key }) | Select-Object -First 1
    $connection = @($raw.WmiMonitorConnectionParams | Where-Object { (Instance-Key $_.InstanceName) -eq $key }) | Select-Object -First 1
    $paths = @($native | Where-Object { (Instance-Key $_.device_path) -eq $key })
    $edid = $null
    try {
        $bytes = (Get-ItemProperty -LiteralPath ('HKLM:\SYSTEM\CurrentControlSet\Enum\' + $key + '\Device Parameters') -Name EDID).EDID
        $edid = Decode-Edid $bytes
    } catch { Warn "EDID unavailable for ${key}: $($_.Exception.Message)" }
    $name = Text-ID $id.UserFriendlyName
    if (-not $name -and $edid) { $name=$edid.model_name }
    if (-not $name -and $paths.Count -gt 0) { $name=$paths[0].friendly_name }
    if (-not $name) { $name=($pnp | Where-Object { (Instance-Key $_.InstanceId) -eq $key } | Select-Object -First 1).FriendlyName }
    $serial = Text-ID $id.SerialNumberID
    if (-not $serial -and $edid) { $serial=$edid.serial_text }
    $manufacturer = Text-ID $id.ManufacturerName
    if (-not $manufacturer -and $edid) { $manufacturer=$edid.manufacturer_code }
    $modes=@(); $preferred=$null
    if ($listed) {
        $index=0
        foreach ($m in $listed.MonitorSourceModes) {
            $mode=[pscustomobject]@{
                width=$m.HorizontalActivePixels; height=$m.VerticalActivePixels
                refresh_hz=if ($m.VerticalRefreshRateDenominator -gt 0) { [math]::Round($m.VerticalRefreshRateNumerator/$m.VerticalRefreshRateDenominator,4) } else { $null }
                interlaced=$m.IsInterlaced; pixel_clock_hz=$m.PixelClockRate
                source='WmiMonitorListedSupportedSourceModes; EDID/driver-reported'
            }
            $modes += $mode
            if ($index -eq $listed.PreferredMonitorSourceModeIndex) { $preferred=$mode }
            $index++
        }
    }
    $width=$null; $height=$null; $diagonal=$null
    if ($basic.MaxHorizontalImageSize -gt 0 -and $basic.MaxVerticalImageSize -gt 0) {
        $width=10*$basic.MaxHorizontalImageSize; $height=10*$basic.MaxVerticalImageSize
    } elseif ($edid.width_cm -gt 0 -and $edid.height_cm -gt 0) { $width=10*$edid.width_cm; $height=10*$edid.height_cm }
    if ($width -and $height) { $diagonal=[math]::Round([math]::Sqrt($width*$width+$height*$height)/25.4,2) }
    $monitors += [pscustomobject][ordered]@{
        observation_id=($scanId + ':' + ($monitors.Count+1)); asset_label=''; location=$Location
        os_instance_id=$key; active=if ($paths.Count -gt 0) { $true } elseif ($id) { $id.Active } elseif ($basic) { $basic.Active } else { $null }
        identity=[pscustomobject]@{ model_name=$name; manufacturer_code=$manufacturer; product_code=(Text-ID $id.ProductCodeID); serial_text=$serial; serial_numeric=$edid.serial_numeric; match_status='Manufacturer match pending' }
        physical=[pscustomobject]@{ width_mm=$width; height_mm=$height; diagonal_inches_approx=$diagonal; source='EDID/WMI reported image dimensions; may be rounded' }
        manufacture=[pscustomobject]@{ week=$id.WeekOfManufacture; year=$id.YearOfManufacture; edid_year_kind=$edid.year_kind }
        advertised_modes=$modes; preferred_reported_mode=$preferred
        current_connections=$paths; wmi_connection_code=$connection.VideoOutputTechnology; edid=$edid
        manufacturer_specifications=$null
        notes=@('This is a connection snapshot, not a verified maximum-capability specification.','Serials may be blank or duplicated; asset labels must distinguish identical units.','EDID may be cached, overridden, or altered by adapters. Original raw bytes are retained.')
    }
}
# Preserve active paths even when Windows does not return a usable identity path.
foreach ($n in $native) {
    if (-not (Instance-Key $n.device_path)) {
        $monitors += [pscustomobject]@{ observation_id=($scanId+':'+($monitors.Count+1)); asset_label=''; location=$Location; active=$true; identity=@{model_name=$n.friendly_name;match_status='Unidentified active target'}; current_connections=@($n); manufacturer_specifications=$null }
    }
}
if ($monitors.Count -eq 0) { Warn 'No monitors reported. Run locally with displays connected and awake; remote sessions and headless systems may expose no physical monitors.' }
$report = [ordered]@{
    schema_version='monitor-baseline/1.0'; collector_version='1.2.0'; platform='Windows'
    scan_id=$scanId; captured_at_utc=[DateTime]::UtcNow.ToString('o')
    computer_label=$ComputerLabel; location=$Location; os_version=[Environment]::OSVersion.VersionString
    output_context=[pscustomobject]@{ desktop_user=$desktopUser.AccountName; desktop_user_sid=$desktopUser.UserSid; desktop_path=$desktopUser.DesktopPath; output_directory=$OutputDirectory }
    monitors=$monitors; graphics_adapters=$gpus; warnings=@($warnings.ToArray())
    collection_scope='Read-only local display APIs, monitor WMI classes, and per-monitor registry EDID. No web lookups or display-setting changes.'
}
Save-Json $report (Join-Path $out 'monitor-baseline.json')
$csv=@($monitors | ForEach-Object {
    [pscustomobject][ordered]@{
        observation_id=$_.observation_id; asset_label=$_.asset_label; computer_label=$ComputerLabel; location=$Location
        active=$_.active; model=$_.identity.model_name; manufacturer=$_.identity.manufacturer_code
        serial=$_.identity.serial_text; diagonal_inches_approx=$_.physical.diagonal_inches_approx
        preferred_width=$_.preferred_reported_mode.width; preferred_height=$_.preferred_reported_mode.height
        preferred_refresh_hz=$_.preferred_reported_mode.refresh_hz; advertised_mode_count=@($_.advertised_modes).Count
        manufacturer_match='Pending'; edid_sha256=$_.edid.sha256
    }
})
if ($csv.Count -gt 0) {
    foreach ($row in $csv) { foreach ($property in $row.PSObject.Properties) {
        if ($property.Value -is [string] -and $property.Value -match '^[=+@\-\t\r]') { $property.Value="'"+$property.Value }
    } }
    $csv | Export-Csv -NoTypeInformation -Encoding UTF8 -LiteralPath (Join-Path $out 'monitor-summary.csv')
}
else { 'No monitors detected; see monitor-baseline.json warnings.' | Set-Content (Join-Path $out 'NO-MONITORS.txt') }
@"
Monitor baseline $scanId
Captured monitors: $($monitors.Count)
Upload monitor-baseline.json or this entire scan ZIP. CSV is only an index.
Current settings and reported supported modes are stored separately.
Raw EDID extensions are retained for later manufacturer/specification analysis.
No complete manufacturer capability table is inferred from OS mode lists.
"@ | Set-Content -LiteralPath (Join-Path $out 'READ-ME.txt') -Encoding UTF8
try {
    Compress-Archive -LiteralPath $out -DestinationPath ($out + '.zip')
    Grant-DesktopUserAccess -Path ($out + '.zip') -UserSid $desktopUser.UserSid
    Write-Host "Ready to upload: $out.zip"
} catch { Warn "ZIP creation or desktop-user access setup failed; report files are in ${out}: $($_.Exception.Message)" }
Write-Host "Monitor observations: $($monitors.Count). Output folder: $out"
