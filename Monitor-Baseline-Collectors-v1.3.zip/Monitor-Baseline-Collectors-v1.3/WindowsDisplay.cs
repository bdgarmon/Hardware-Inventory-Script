// Read-only Windows display APIs. Compatible with Windows PowerShell 5.1 Add-Type.
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;

public static class MonitorBaselineNative {
    [StructLayout(LayoutKind.Sequential)] struct Luid { public uint Low; public int High; }
    [StructLayout(LayoutKind.Sequential)] struct Rational { public uint N, D; }
    [StructLayout(LayoutKind.Sequential)] struct Source { public Luid Adapter; public uint Id, ModeIndex, Status; }
    [StructLayout(LayoutKind.Sequential)] struct Target {
        public Luid Adapter; public uint Id, ModeIndex, Technology, Rotation, Scaling;
        public Rational Refresh; public uint Scanline; public int Available; public uint Status;
    }
    [StructLayout(LayoutKind.Sequential)] struct Path { public Source Source; public Target Target; public uint Flags; }
    [StructLayout(LayoutKind.Explicit, Size=64)] struct Mode {
        [FieldOffset(0)] public uint Type;
        [FieldOffset(4)] public uint Id;
        [FieldOffset(8)] public Luid Adapter;
        [FieldOffset(16)] public ulong PixelRate;
        [FieldOffset(24)] public Rational HSync;
        [FieldOffset(32)] public Rational VSync;
        [FieldOffset(40)] public uint ActiveWidth;
        [FieldOffset(44)] public uint ActiveHeight;
    }
    [StructLayout(LayoutKind.Sequential)] struct Header { public uint Type, Size; public Luid Adapter; public uint Id; }
    [StructLayout(LayoutKind.Sequential, CharSet=CharSet.Unicode)] struct TargetName {
        public Header Header; public uint Flags, Technology;
        public ushort Manufacturer, Product; public uint ConnectorInstance;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst=64)] public string FriendlyName;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst=128)] public string DevicePath;
    }
    [StructLayout(LayoutKind.Sequential, CharSet=CharSet.Unicode)] struct SourceName {
        public Header Header;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst=32)] public string GdiName;
    }
    [StructLayout(LayoutKind.Sequential)] struct ColorInfo {
        public Header Header; public uint Flags, Encoding, BitsPerChannel;
    }
    [StructLayout(LayoutKind.Sequential, CharSet=CharSet.Unicode)] struct DevMode {
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst=32)] public string DeviceName;
        public ushort SpecVersion, DriverVersion, Size, DriverExtra;
        public uint Fields; public int X, Y; public uint Orientation, FixedOutput;
        public short Color, Duplex, YResolution, TTOption, Collate;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst=32)] public string FormName;
        public ushort LogPixels; public uint BitsPerPel, Width, Height, DisplayFlags, Frequency;
        public uint ICMMethod, ICMIntent, MediaType, DitherType, Reserved1, Reserved2, PanningWidth, PanningHeight;
    }
    [DllImport("user32.dll")] static extern int GetDisplayConfigBufferSizes(uint flags, out uint paths, out uint modes);
    [DllImport("user32.dll")] static extern int QueryDisplayConfig(uint flags, ref uint paths, [Out] Path[] pathArray, ref uint modes, [Out] Mode[] modeArray, IntPtr topology);
    [DllImport("user32.dll", EntryPoint="DisplayConfigGetDeviceInfo")] static extern int GetName(ref TargetName request);
    [DllImport("user32.dll", EntryPoint="DisplayConfigGetDeviceInfo")] static extern int GetSource(ref SourceName request);
    [DllImport("user32.dll", EntryPoint="DisplayConfigGetDeviceInfo")] static extern int GetColor(ref ColorInfo request);
    [DllImport("user32.dll", CharSet=CharSet.Unicode)] static extern bool EnumDisplaySettingsEx(string name, int index, ref DevMode mode, uint flags);

    static Header MakeHeader(uint type, Type structure, Luid adapter, uint id) {
        return new Header { Type=type, Size=(uint)Marshal.SizeOf(structure), Adapter=adapter, Id=id };
    }
    static Dictionary<string,object> Describe(DevMode d) {
        return new Dictionary<string,object> {
            {"width",d.Width},{"height",d.Height},{"refresh_hz",d.Frequency>1 ? (object)d.Frequency : null},
            {"framebuffer_bits_per_pixel",d.BitsPerPel},{"interlaced",(d.DisplayFlags & 2)!=0},
            {"orientation_code",d.Orientation},{"source","EnumDisplaySettingsEx; OS-exposed mode"}
        };
    }
    public static List<Dictionary<string,object>> Collect() {
        if(Marshal.SizeOf(typeof(Path))!=72 || Marshal.SizeOf(typeof(Mode))!=64 || Marshal.SizeOf(typeof(DevMode))!=220)
            throw new Exception("Unexpected Windows display structure size");
        for(int retry=0;retry<4;retry++) {
            uint pc, mc; int error=GetDisplayConfigBufferSizes(2,out pc,out mc);
            if(error!=0) throw new Exception("GetDisplayConfigBufferSizes: "+error);
            Path[] paths=new Path[pc]; Mode[] modes=new Mode[mc];
            error=QueryDisplayConfig(2,ref pc,paths,ref mc,modes,IntPtr.Zero);
            if(error==122) continue;
            if(error!=0) throw new Exception("QueryDisplayConfig: "+error);
            var result=new List<Dictionary<string,object>>();
            for(int i=0;i<pc;i++) {
                Path p=paths[i];
                TargetName tn=new TargetName {Header=MakeHeader(2,typeof(TargetName),p.Target.Adapter,p.Target.Id)};
                SourceName sn=new SourceName {Header=MakeHeader(1,typeof(SourceName),p.Source.Adapter,p.Source.Id)};
                int nameError=GetName(ref tn), sourceError=GetSource(ref sn);
                var row=new Dictionary<string,object> {
                    {"friendly_name",nameError==0?tn.FriendlyName:null},{"device_path",nameError==0?tn.DevicePath:null},
                    {"gdi_source",sourceError==0?sn.GdiName:null},{"target_id",p.Target.Id},
                    {"adapter_luid",p.Target.Adapter.High.ToString("X8")+p.Target.Adapter.Low.ToString("X8")},
                    {"connection_code",p.Target.Technology},{"rotation_code",p.Target.Rotation},
                    {"scaling_code",p.Target.Scaling},{"name_query_error",nameError},{"source_query_error",sourceError},
                    {"current_path_refresh_hz",p.Target.Refresh.D>0 ? (object)Math.Round((double)p.Target.Refresh.N/p.Target.Refresh.D,4):null}
                };
                if(p.Target.ModeIndex<mc && modes[p.Target.ModeIndex].Type==2) {
                    Mode m=modes[p.Target.ModeIndex];
                    row["current_signal"]=new Dictionary<string,object> {
                        {"width",m.ActiveWidth},{"height",m.ActiveHeight},{"pixel_clock_hz",m.PixelRate},
                        {"vertical_sync_hz",m.VSync.D>0?(object)Math.Round((double)m.VSync.N/m.VSync.D,4):null}
                    };
                }
                ColorInfo color=new ColorInfo {Header=MakeHeader(9,typeof(ColorInfo),p.Target.Adapter,p.Target.Id)};
                int ce=GetColor(ref color);
                row["advanced_color_query_error"]=ce;
                if(ce==0) row["advanced_color"]=new Dictionary<string,object> {
                    {"supported",(color.Flags&1)!=0},{"enabled",(color.Flags&2)!=0},
                    {"wide_color_enforced",(color.Flags&4)!=0},{"force_disabled",(color.Flags&8)!=0},
                    {"encoding_code",color.Encoding},{"current_bits_per_channel",color.BitsPerChannel},
                    {"note","Advanced color is not proof of HDR quality or the panel's maximum bit depth."}
                };
                var available=new List<Dictionary<string,object>>();
                var seen=new HashSet<string>();
                if(sourceError==0) {
                    DevMode dm=new DevMode {Size=(ushort)Marshal.SizeOf(typeof(DevMode))};
                    if(EnumDisplaySettingsEx(sn.GdiName,-1,ref dm,0)) row["current_desktop_mode"]=Describe(dm);
                    for(int j=0;j<20000;j++) {
                        dm=new DevMode {Size=(ushort)Marshal.SizeOf(typeof(DevMode))};
                        if(!EnumDisplaySettingsEx(sn.GdiName,j,ref dm,0)) break;
                        string key=dm.Width+"x"+dm.Height+"@"+dm.Frequency+"/"+dm.BitsPerPel+"/"+dm.DisplayFlags+"/"+dm.Orientation;
                        if(seen.Add(key)) available.Add(Describe(dm));
                        if(j==19999) row["mode_enumeration_truncated"]=true;
                    }
                }
                row["available_modes"]=available;
                row["mode_scope"]="OS/driver modes for this source and connection; mirrored targets can share a source. Not the manufacturer's complete supported-mode table.";
                result.Add(row);
            }
            return result;
        }
        throw new Exception("Display topology kept changing; rerun after connections settle.");
    }
}
