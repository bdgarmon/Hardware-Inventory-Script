#!/bin/bash
# macOS 11+; baseline needs only built-in macOS utilities. No sudo or installs.
set -euo pipefail
KIT_DIR="$(cd "$(dirname "$0")" && pwd)"
ROOT="${1:-$HOME/Desktop/Monitor-Baselines}"
mkdir -p "$ROOT"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
OUT="$(mktemp -d "$ROOT/macOS-$STAMP-XXXXXX")"
mkdir -p "$OUT/raw"
echo "Collecting monitor baseline..."
/usr/sbin/system_profiler SPDisplaysDataType -json > "$OUT/raw/system-profiler-displays.json" 2> "$OUT/raw/system-profiler-errors.txt" || true
# Limit the registry export to properties relevant to displays; do not collect
# the entire IORegistry (which includes unrelated device/network information).
REGISTRY_FAILED=0
for KEY in IODisplayEDID DisplayProductID DisplayAttributes display-attributes; do
    if ! /usr/sbin/ioreg -a -l -r -k "$KEY" > "$OUT/raw/registry-$KEY-temporary.plist" 2> "$OUT/raw/registry-query-error.tmp"; then
        REGISTRY_FAILED=1
        echo "Registry query failed for $KEY:" >> "$OUT/raw/ioreg-errors.txt"
    fi
    cat "$OUT/raw/registry-query-error.tmp" >> "$OUT/raw/ioreg-errors.txt"
done
rm -f "$OUT/raw/registry-query-error.tmp"
trap 'rm -f "$OUT"/raw/registry-*-temporary.plist' EXIT
if /usr/bin/xcode-select -p >/dev/null 2>&1; then
    mkdir -p "$OUT/raw/swift-module-cache"
    if [ "$REGISTRY_FAILED" -eq 1 ]; then
        if /usr/bin/xcrun swift -module-cache-path "$OUT/raw/swift-module-cache" "$KIT_DIR/MonitorRegistry.swift" > "$OUT/raw/display-registry-fallback.tmp" 2> "$OUT/raw/registry-fallback-errors.txt"; then
            mv "$OUT/raw/display-registry-fallback.tmp" "$OUT/raw/display-registry.json"
            echo "Direct IOKit fallback completed; original ioreg warning retained." > "$OUT/raw/registry-fallback-status.txt"
        else
            rm -f "$OUT/raw/display-registry-fallback.tmp"
            echo "Direct IOKit fallback failed; other display collection continues." >> "$OUT/raw/ioreg-errors.txt"
        fi
    fi
    /usr/bin/xcrun swift -module-cache-path "$OUT/raw/swift-module-cache" "$KIT_DIR/MonitorNative.swift" > "$OUT/raw/coregraphics.json" 2> "$OUT/raw/coregraphics-errors.txt" || true
    rm -rf "$OUT/raw/swift-module-cache"
else
    if [ "$REGISTRY_FAILED" -eq 1 ]; then
        echo "Direct IOKit fallback requires existing Apple command-line developer tools; not installed by this script." >> "$OUT/raw/ioreg-errors.txt"
    fi
    echo "Optional CoreGraphics mode enumeration skipped: Apple command-line developer tools are not installed. Built-in System Information and EDID collection still ran." > "$OUT/raw/coregraphics-errors.txt"
fi
/usr/bin/osascript -l JavaScript "$KIT_DIR/normalize-macos.js" "$OUT"
rm -f "$OUT"/raw/registry-*-temporary.plist
trap - EXIT
if /usr/bin/ditto -c -k --keepParent "$OUT" "$OUT.zip"; then
    echo "Ready to upload: $OUT.zip"
else
    echo "ZIP creation failed; the complete report is in: $OUT"
fi
