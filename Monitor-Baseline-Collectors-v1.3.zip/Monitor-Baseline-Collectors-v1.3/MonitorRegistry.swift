import Foundation
import IOKit

// Read registry properties in memory; serialize only display-specific keys.
let allowed = Set(["IODisplayEDID", "DisplayVendorID", "DisplayProductID", "DisplaySerialNumber", "DisplayProductName", "IODisplayPrefsKey", "IORegistryEntryName", "IORegistryEntryID", "IODisplayLocation", "IODisplayAttributes", "DisplayAttributes", "display-attributes"])
let selectors = ["IODisplayEDID", "DisplayProductID", "DisplayAttributes", "display-attributes"]
func jsonValue(_ value: Any) -> Any {
    if let data = value as? Data { return ["base64": data.base64EncodedString()] }
    if let dict = value as? [String: Any] { return dict.mapValues { jsonValue($0) } }
    if let array = value as? [Any] { return array.map { jsonValue($0) } }
    if value is String || value is NSNumber { return value }
    return String(describing: value)
}
var iterator: io_iterator_t = 0
let status = IORegistryCreateIterator(kIOMasterPortDefault, kIOServicePlane, IOOptionBits(kIORegistryIterateRecursively), &iterator)
guard status == KERN_SUCCESS else {
    fputs("IORegistry iterator failed: \(status)\n", stderr)
    exit(1)
}
defer { IOObjectRelease(iterator) }
var rows: [[String: Any]] = []
while case let entry = IOIteratorNext(iterator), entry != 0 {
    defer { IOObjectRelease(entry) }
    var unmanaged: Unmanaged<CFMutableDictionary>?
    guard IORegistryEntryCreateCFProperties(entry, &unmanaged, kCFAllocatorDefault, 0) == KERN_SUCCESS,
          let properties = unmanaged?.takeRetainedValue() as? [String: Any],
          selectors.contains(where: { properties[$0] != nil }) else { continue }
    var row: [String: Any] = [:]
    for (key, value) in properties where allowed.contains(key) {
        if let data = value as? Data { row[key + "_base64"] = data.base64EncodedString() }
        else { row[key] = jsonValue(value) }
    }
    rows.append(row)
}
do {
    let data = try JSONSerialization.data(withJSONObject: rows, options: [.prettyPrinted, .sortedKeys])
    FileHandle.standardOutput.write(data)
} catch {
    fputs("Display property serialization failed: \(error)\n", stderr)
    exit(1)
}
