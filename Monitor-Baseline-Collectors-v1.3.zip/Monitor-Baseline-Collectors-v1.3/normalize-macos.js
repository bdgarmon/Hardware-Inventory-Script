// JavaScript for Automation (osascript), using macOS Foundation/AppKit.
ObjC.import('Foundation');
ObjC.import('AppKit');
ObjC.import('CoreGraphics');

function run(argv) {
    const out = argv[0];
    if (!out) throw Error('Output folder required');
    const warnings = [];
    function read(path) {
        const error = Ref();
        const value = $.NSString.stringWithContentsOfFileEncodingError(path, $.NSUTF8StringEncoding, error);
        if (!value || value.isNil()) return null;
        return ObjC.unwrap(value);
    }
    function write(path, text) {
        const error = Ref();
        if (!$(text).writeToFileAtomicallyEncodingError(path, true, $.NSUTF8StringEncoding, error)) throw Error('Cannot write ' + path);
    }
    function jsonFile(path, fallback) {
        try { const text = read(path); if (text) return JSON.parse(text); }
        catch(e) { warnings.push('Could not parse ' + path.split('/').pop() + ': ' + e.message); }
        return fallback;
    }
    function base64Bytes(s) {
        const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
        let bits = 0, value = 0; const bytes = [];
        for (const char of s) {
            const n = alphabet.indexOf(char); if (n < 0) continue;
            value = (value << 6) | n; bits += 6;
            if (bits >= 8) { bits -= 8; bytes.push((value >> bits) & 255); }
        }
        return bytes;
    }
    function decodeEdid(base64) {
        const b = base64Bytes(base64);
        const checks = [];
        for (let o=0;o+127<b.length;o+=128) checks.push(b.slice(o,o+128).reduce((a,n)=>a+n,0)%256===0);
        const r = {byte_count:b.length,hex:b.map(x=>('0'+x.toString(16)).slice(-2)).join('').toUpperCase(),block_checksums_valid:checks};
        if (b.length<128 || r.hex.slice(0,16)!=='00FFFFFFFFFFFF00' || !checks[0]) {
            r.decode_status='Invalid/truncated base EDID; raw bytes retained'; return r;
        }
        r.vendor_id=(b[8]<<8)|b[9];
        r.manufacturer_code=[10,5,0].map(n=>String.fromCharCode(64+((r.vendor_id>>n)&31))).join('');
        r.product_id=b[10]+b[11]*256;
        r.serial_numeric=b[12]+b[13]*256+b[14]*65536+b[15]*16777216;
        r.manufacture_week=b[16]>=1&&b[16]<=54?b[16]:null;
        r.year=1990+b[17]; r.year_kind=b[16]===255?'model_year':'manufacture_year';
        r.edid_version=b[18]+'.'+b[19];
        r.width_cm=b[21]&&b[22]?b[21]:null; r.height_cm=b[21]&&b[22]?b[22]:null;
        r.extension_blocks_declared=b[126]; r.extension_blocks_captured=Math.max(0,Math.floor(b.length/128)-1);
        r.base_detailed_timings=[];
        for (let o=54;o<=108;o+=18) {
            const clock=(b[o]+b[o+1]*256)*10000;
            if (!clock) {
                const text=String.fromCharCode.apply(null,b.slice(o+5,o+18)).replace(/[\x00\r\n]/g,'').trim();
                if(b[o+3]===252)r.model_name=text;
                if(b[o+3]===255)r.serial_text=text;
                if(b[o+3]===253)r.range_descriptor_hex=r.hex.slice(o*2,(o+18)*2);
            } else {
                const w=b[o+2]+((b[o+4]&240)<<4),h=b[o+5]+((b[o+7]&240)<<4);
                const hb=b[o+3]+((b[o+4]&15)<<8),vb=b[o+6]+((b[o+7]&15)<<8);
                const interlaced=!!(b[o+17]&128);
                r.base_detailed_timings.push({width:w,height_as_encoded:h,interlaced:interlaced,pixel_clock_hz:clock,
                    refresh_hz:!interlaced&&(w+hb)*(h+vb)>0?Math.round(clock/((w+hb)*(h+vb))*10000)/10000:null,
                    source:'EDID base detailed timing; not independently verified native resolution'});
            }
        }
        r.decode_status='Valid base EDID; extension bytes retained for later decoding';
        return r;
    }
    const registry=jsonFile(out+'/raw/display-registry.json',[]);
    for (const row of registry) {
        if (row.IODisplayEDID_base64) row.edid=decodeEdid(row.IODisplayEDID_base64);
    }
    function plain(value) {
        if(value.isKindOfClass($.NSData))return {base64:ObjC.unwrap(value.base64EncodedStringWithOptions(0))};
        if(value.isKindOfClass($.NSArray)) { const a=[]; for(let i=0;i<value.count;i++)a.push(plain(value.objectAtIndex(i))); return a; }
        if(value.isKindOfClass($.NSDictionary)) { const r={},keys=value.allKeys; for(let i=0;i<keys.count;i++){const k=ObjC.unwrap(keys.objectAtIndex(i));r[k]=plain(value.objectForKey(k));}return r; }
        return ObjC.unwrap(value);
    }
    for(const registryKey of ['IODisplayEDID','DisplayProductID','DisplayAttributes','display-attributes']) { try {
        const data=$.NSData.dataWithContentsOfFile(out+'/raw/registry-'+registryKey+'-temporary.plist');
        if (!data || data.isNil() || Number(data.length)===0) continue;
        const plist=$.NSPropertyListSerialization.propertyListWithDataOptionsFormatError(data,0,null,null);
        if (!plist || plist.isNil()) throw Error('Invalid registry property list');
        function walk(node) {
            if (node.isKindOfClass($.NSArray)) {
                for(let i=0;i<node.count;i++)walk(node.objectAtIndex(i));
            } else if (node.isKindOfClass($.NSDictionary)) {
                const edid=node.objectForKey('IODisplayEDID');
                const product=node.objectForKey('DisplayProductID');
                const attrs=node.objectForKey('DisplayAttributes');
                const lowerAttrs=node.objectForKey('display-attributes');
                if ((edid&&!edid.isNil())||(product&&!product.isNil())||(attrs&&!attrs.isNil())||(lowerAttrs&&!lowerAttrs.isNil())) {
                    const row={};
                    // Keep only display identity and display-specific properties.
                    const keys=node.allKeys;
                    for(let i=0;i<keys.count;i++) {
                        const key=ObjC.unwrap(keys.objectAtIndex(i));
                        if(!/^(IODisplayEDID|DisplayVendorID|DisplayProductID|DisplaySerialNumber|DisplayProductName|IODisplayPrefsKey|IORegistryEntryName|IORegistryEntryID|IODisplayLocation|IODisplayAttributes|DisplayAttributes|display-attributes)$/.test(key))continue;
                        const value=node.objectForKey(key);
                        if(value.isKindOfClass($.NSData)) {
                            row[key+'_base64']=ObjC.unwrap(value.base64EncodedStringWithOptions(0));
                        } else {
                            try { row[key]=plain(value); } catch(e) { row[key]=ObjC.unwrap(value.description); }
                        }
                    }
                    if(row.IODisplayEDID_base64)row.edid=decodeEdid(row.IODisplayEDID_base64);
                    if(!registry.some(existing=>JSON.stringify(existing)===JSON.stringify(row)))registry.push(row);
                }
                const children=node.objectForKey('IORegistryEntryChildren');
                if(children&&!children.isNil())walk(children);
            }
        }
        walk(plist);
    } catch(e) { warnings.push('Display registry extraction unavailable for '+registryKey+': '+e.message); } }
    write(out+'/raw/display-registry.json',JSON.stringify(registry,null,2));
    const profiler=jsonFile(out+'/raw/system-profiler-displays.json',{});
    const profilerDisplays=[];
    for(const gpu of (profiler.SPDisplaysDataType||[])) {
        for(const display of (gpu.spdisplays_ndrvs||[]))profilerDisplays.push({gpu_name:gpu._name,display:display});
    }
    let native=jsonFile(out+'/raw/coregraphics.json',[]);
    if (!Array.isArray(native)) native=[];
    if (!native.length) {
        // Baseline fallback requires no compiler, Python, Homebrew, or downloads.
        try {
            const screens=$.NSScreen.screens;
            for(let i=0;i<screens.count;i++) {
                const screen=screens.objectAtIndex(i);
                const id=Number(ObjC.unwrap(screen.deviceDescription.objectForKey('NSScreenNumber')));
                const size=$.CGDisplayScreenSize(id),mode=$.CGDisplayCopyDisplayMode(id);
                const row={display_id:id,vendor_id:$.CGDisplayVendorNumber(id),product_id:$.CGDisplayModelNumber(id),
                    serial_numeric:$.CGDisplaySerialNumber(id),built_in:!!$.CGDisplayIsBuiltin(id),active:!!$.CGDisplayIsActive(id),
                    main:!!$.CGDisplayIsMain(id),width_mm:size.width||null,height_mm:size.height||null,
                    available_modes:[],mode_enumeration_status:'Not collected; optional Swift helper did not return displays'};
                try { row.name=ObjC.unwrap(screen.localizedName); }catch(e){}
                if(mode) row.current_mode={width:$.CGDisplayModeGetWidth(mode),height:$.CGDisplayModeGetHeight(mode),
                    pixel_width:$.CGDisplayModeGetPixelWidth(mode),pixel_height:$.CGDisplayModeGetPixelHeight(mode),
                    refresh_hz:$.CGDisplayModeGetRefreshRate(mode)||null,source:'CoreGraphics current mode'};
                native.push(row);
            }
        }catch(e){warnings.push('AppKit display fallback unavailable: '+e.message);}
    }
    function positiveID(value,hexadecimal) {
        if(typeof value==='number')return value;
        if(typeof value!=='string')return null;
        if(hexadecimal&&/^[0-9a-f]+$/i.test(value))return parseInt(value,16);
        if(/^0x[0-9a-f]+$/i.test(value))return parseInt(value,16);
        if(/^[0-9]+$/.test(value))return Number(value);
        return null;
    }
    const scanId=ObjC.unwrap($.NSUUID.UUID.UUIDString);
    let host='Unknown Mac';
    try { host=ObjC.unwrap($.NSProcessInfo.processInfo.hostName); }catch(e){}
    const monitors=[];
    const bases=native.length?native:profilerDisplays.map(p=>({name:p.display._name,profiler:p.display,
        vendor_id:positiveID(p.display['_spdisplays_display-vendor-id'],true),product_id:positiveID(p.display['_spdisplays_display-product-id'],true),
        serial_numeric:positiveID(p.display['_spdisplays_display-serial-number'],true),available_modes:[]}));
    function registryIdentity(r) {
        if(r.edid&&r.edid.vendor_id)return r.edid;
        const a=r.DisplayAttributes||r['display-attributes']||{};
        const p=a.ProductAttributes||{};
        return {vendor_id:p.LegacyManufacturerID,product_id:p.ProductID,serial_numeric:p.SerialNumber,
            serial_text:p.AlphanumericSerialNumber,model_name:p.ProductName,manufacturer_code:p.ManufacturerID,
            year:p.YearOfManufacture,manufacture_week:p.WeekOfManufacture,year_kind:'manufacture_year'};
    }
    function registryKey(r) {return JSON.stringify(registryIdentity(r))+'|'+(r.edid?r.edid.hex:'');}
    const usedRegistry=[];
    for(const n of bases) {
        let candidates=registry.filter(r=>{const id=registryIdentity(r);return id.vendor_id&&id.product_id&&id.vendor_id===n.vendor_id&&id.product_id===n.product_id;});
        if(n.serial_numeric)candidates=candidates.filter(r=>registryIdentity(r).serial_numeric===n.serial_numeric);
        // Deduplicate identical registry records but never assign one identity
        // ambiguously across multiple same-model displays with missing serials.
        candidates=candidates.filter((r,i,a)=>a.findIndex(x=>registryKey(x)===registryKey(r))===i);
        const peers=bases.filter(x=>x.vendor_id===n.vendor_id&&x.product_id===n.product_id&&(!n.serial_numeric||x.serial_numeric===n.serial_numeric));
        const match=candidates.length===1&&peers.length===1?candidates[0]:null;
        if(match)usedRegistry.push(match);
        const edid=match?match.edid||null:null;
        const rid=match?registryIdentity(match):{};
        const attrs=match?(match.DisplayAttributes||match['display-attributes']||null):null;
        const width=n.width_mm||(edid&&edid.width_cm?edid.width_cm*10:null);
        const height=n.height_mm||(edid&&edid.height_cm?edid.height_cm*10:null);
        monitors.push({
            observation_id:scanId+':'+(monitors.length+1),asset_label:'',location:'',
            os_instance_id:n.display_uuid||n.display_id||null,active:typeof n.active==='boolean'?n.active:null,built_in:n.built_in===undefined?null:n.built_in,
            identity:{model_name:n.name||rid.model_name||null,manufacturer_code:rid.manufacturer_code||null,
                vendor_id:n.vendor_id||null,product_id:n.product_id||null,serial_numeric:n.serial_numeric||null,
                serial_text:rid.serial_text||null,match_status:'Manufacturer match pending'},
            physical:{width_mm:width,height_mm:height,diagonal_inches_approx:width&&height?Math.round(Math.sqrt(width*width+height*height)/25.4*100)/100:null,
                source:'CoreGraphics/EDID reported dimensions; may be rounded'},
            manufacture:rid.year?{week:rid.manufacture_week||null,year:rid.year,edid_year_kind:rid.year_kind,
                source:edid?'EDID':'Apple DisplayAttributes.ProductAttributes'}:null,
            advertised_modes:edid?edid.base_detailed_timings:[],preferred_reported_mode:null,
            current_connections:[n],edid:edid,manufacturer_specifications:null,
            registry_display_attributes:attrs,
            reported_capabilities:attrs?{source:'Apple DisplayAttributes; reported support, not current enablement',
                minimum_refresh_hz:attrs.MinimumRefreshRate===undefined?null:attrs.MinimumRefreshRate,
                maximum_refresh_hz:attrs.MaximumRefreshRate===undefined?null:attrs.MaximumRefreshRate,
                variable_refresh_supported:attrs.SupportsVariableRefreshRate===undefined?null:attrs.SupportsVariableRefreshRate,
                pq_eotf_supported:attrs.SupportsPQEOTF===undefined?null:attrs.SupportsPQEOTF,
                hdr_static_metadata_type1_supported:attrs.SupportsHDRStaticMetadataType1===undefined?null:attrs.SupportsHDRStaticMetadataType1}:null,
            notes:['OS mode dimensions may describe scaled rendering; no native-panel resolution is inferred.',
                'Zero/unknown refresh remains unknown; it is not replaced with 60 Hz.',
                match?(edid?'EDID identity matched uniquely.':'Apple ProductAttributes matched uniquely; raw EDID is unavailable.'):'No unique registry identity match; unmatched records are retained separately.']
        });
    }
    const helperErrors=read(out+'/raw/coregraphics-errors.txt');
    if(helperErrors&&helperErrors.trim())warnings.push('Optional CoreGraphics helper: '+helperErrors.trim().slice(0,1500));
    for(const file of ['system-profiler-errors.txt','ioreg-errors.txt']) {
        const err=read(out+'/raw/'+file); if(err&&err.trim())warnings.push(file+': '+err.trim().slice(0,1500));
    }
    if(!monitors.length)warnings.push('No monitors reported. Run locally with displays connected and awake; this may be a headless or remote session.');
    const report={schema_version:'monitor-baseline/1.0',collector_version:'1.3.0',platform:'macOS',scan_id:scanId,
        captured_at_utc:new Date().toISOString(),computer_label:host,location:'',os_version:ObjC.unwrap($.NSProcessInfo.processInfo.operatingSystemVersionString),
        monitors:monitors,graphics_adapters:(profiler.SPDisplaysDataType||[]).map(g=>({name:g._name,model:g.sppci_model,vendor:g.spdisplays_vendor})),
        unmatched_registry_displays:registry.filter(r=>!usedRegistry.some(x=>registryKey(x)===registryKey(r))),
        profiler_display_records:profilerDisplays,warnings:warnings,
        collection_scope:'Read-only System Information, display-filtered IORegistry, and CoreGraphics where available. No web lookups or display-setting changes.'};
    write(out+'/monitor-baseline.json',JSON.stringify(report,null,2));
    function csv(value) {
        let text=value===null||value===undefined?'':String(value);
        if(/^[=+@\-\t\r]/.test(text))text="'"+text;
        return '"'+text.replace(/"/g,'""')+'"';
    }
    const header=['observation_id','asset_label','computer_label','location','active','built_in','model','manufacturer','serial','diagonal_inches_approx','advertised_mode_count','os_exposed_mode_count','manufacturer_match'];
    const rows=monitors.map(m=>[m.observation_id,'',host,'',m.active,m.built_in,m.identity.model_name,m.identity.manufacturer_code,m.identity.serial_text||m.identity.serial_numeric,m.physical.diagonal_inches_approx,m.advertised_modes.length,(m.current_connections[0].available_modes||[]).length,'Pending']);
    write(out+'/monitor-summary.csv','\uFEFF'+[header].concat(rows).map(row=>row.map(csv).join(',')).join('\r\n')+'\r\n');
    write(out+'/READ-ME.txt','Monitor baseline '+scanId+'\nMonitor observations: '+monitors.length+'\nUpload monitor-baseline.json or the entire scan ZIP. CSV is only an index.\nOS mode lists are not a manufacturer capability table. Raw EDID extensions and unlinked display evidence are retained.\n');
    return 'Collected '+monitors.length+' monitor observations. Warnings: '+warnings.length+'. Report: '+out;
}
